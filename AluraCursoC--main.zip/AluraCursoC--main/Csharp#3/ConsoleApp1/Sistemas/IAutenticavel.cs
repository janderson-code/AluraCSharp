﻿namespace ConsoleApp1.Sistemas
{
    public interface IAutenticavel
    {
        bool Autenticar(string senha);
    }
}