﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ByteBank.Testes
{
    public class Derivada : Base
    {

        //Propriedade sobrescrita
        public override int Numero { get; set; }

        public override void M()
        {
            base.M();
        }
    }
}
