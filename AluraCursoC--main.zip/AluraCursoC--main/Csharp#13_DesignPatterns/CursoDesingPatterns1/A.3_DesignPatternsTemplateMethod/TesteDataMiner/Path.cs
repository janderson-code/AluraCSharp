﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace A._3_DesignPatternsTemplateMethod.TesteDataMiner
{
    public class Path
    {
        public String caminhoUrl { get; set; }
    }
}