﻿namespace A._3_DesignPatternsMemento
{
    enum TipoContrato
    {
        Novo,EmAndamento,Acertado,Concluido
    }
}