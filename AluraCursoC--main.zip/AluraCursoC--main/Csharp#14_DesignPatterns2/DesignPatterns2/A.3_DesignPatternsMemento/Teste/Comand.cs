﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A._3_DesignPatternsMemento.Teste
{
    // Um objeto comando pode agir como cuidador. Neste caso, o
    // comando obtém o memento antes que ele mude o estado do
    // originador. Quando o undo(desfazer) é solicitado, ele
    // restaura o estado do originador a partir de um memento
    
}
