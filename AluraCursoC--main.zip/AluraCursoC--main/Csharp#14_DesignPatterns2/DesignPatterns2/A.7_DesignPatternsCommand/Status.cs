﻿namespace A._7_DesignPatternsCommand
{
    enum Status
    {
        Novo,
        Processado,
        Pago,
        ItemSeparado,
        Entregue
    }
}