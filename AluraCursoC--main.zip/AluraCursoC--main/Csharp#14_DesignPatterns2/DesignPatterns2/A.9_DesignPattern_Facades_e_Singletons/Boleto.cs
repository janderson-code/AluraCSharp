﻿namespace A._9_DesignPattern_Facades_e_Singletons
{
    public class TipoBoleto
    {
        public TipoBoleto Boleto { get; set; }
    }
}