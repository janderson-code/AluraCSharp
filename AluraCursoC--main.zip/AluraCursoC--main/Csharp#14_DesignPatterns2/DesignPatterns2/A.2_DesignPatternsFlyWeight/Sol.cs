﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class Sol : INota
    {
        public int Frequencia => 392;
    }
}