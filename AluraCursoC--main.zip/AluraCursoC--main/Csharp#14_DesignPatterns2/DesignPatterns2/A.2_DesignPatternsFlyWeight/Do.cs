﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class Do : INota
    {
        public int Frequencia => 262;
    }
}