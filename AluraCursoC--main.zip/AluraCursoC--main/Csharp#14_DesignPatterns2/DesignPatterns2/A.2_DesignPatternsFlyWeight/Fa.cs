﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class Fa : INota
    {
        public int Frequencia => 349;
    }
}