﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class Re : INota
    {
        public int Frequencia => 294;
    }
}