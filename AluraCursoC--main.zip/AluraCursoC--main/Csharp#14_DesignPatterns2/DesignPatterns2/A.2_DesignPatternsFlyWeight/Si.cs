﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class Si : INota
    {
        public int Frequencia => 490;
    }
}