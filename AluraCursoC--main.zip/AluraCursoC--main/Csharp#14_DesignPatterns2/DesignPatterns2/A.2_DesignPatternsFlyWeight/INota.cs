﻿namespace A._2_DesignPatternsFlyWeight
{
    internal interface INota
    {
         int Frequencia { get;}

    }
}