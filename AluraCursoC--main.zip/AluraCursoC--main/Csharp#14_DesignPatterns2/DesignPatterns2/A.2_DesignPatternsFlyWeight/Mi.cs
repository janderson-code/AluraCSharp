﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class Mi : INota
    {
        public int Frequencia => 330;
    }
}