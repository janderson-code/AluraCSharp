﻿namespace A._2_DesignPatternsFlyWeight
{
    internal class La : INota
    {
        public int Frequencia => 444;
    }
}