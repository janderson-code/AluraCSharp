﻿namespace DesignPatterns2.TesteTransporte
{
    public interface ITransportProduct
    {
        void deliver();
    }
}