using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbsctractFactory.Produtos.Classes.Victoriam.Cadeiras
{
    public class VictoriamCadeira : ICadeira
    {
        void hasLegs()
        {

        }
        void sitOn()
        {

        }
    }
}