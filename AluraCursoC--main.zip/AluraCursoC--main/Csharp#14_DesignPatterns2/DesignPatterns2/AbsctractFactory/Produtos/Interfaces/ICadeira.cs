using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbsctractFactory.Produtos.Interfaces
{
    public interface ICadeira
    {
        void hasLegs();
        void sitOn();
    }
}