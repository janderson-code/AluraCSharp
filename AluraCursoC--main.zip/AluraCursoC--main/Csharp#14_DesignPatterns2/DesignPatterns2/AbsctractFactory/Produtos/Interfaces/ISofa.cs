using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbsctractFactory.Produtos.Interfaces
{
    public interface ISofa
    {
        void haslegs();
        void SitOn();
    }
}